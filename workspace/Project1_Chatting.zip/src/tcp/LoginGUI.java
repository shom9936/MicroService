package tcp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class LoginGUI extends JFrame{

	private JPanel contentPane;
	private JTextField textField_ipadd;
	private JTextField textField_portnum;
	private JTextField textField_id;
	private JTextField textField_passwd;
	private String ip;
	private String portnum;
	private String id;
	private boolean stop = false;

	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getPortnum() {
		return portnum;
	}
	public void setPortnum(String portnum) {
		this.portnum = portnum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbl_ipadd = new JLabel("IP \uC8FC\uC18C");
		lbl_ipadd.setBounds(25, 31, 57, 15);
		contentPane.add(lbl_ipadd);
		
		JLabel lbl_portnum = new JLabel("\uD3EC\uD2B8 \uB118\uBC84");
		lbl_portnum.setBounds(25, 62, 57, 15);
		contentPane.add(lbl_portnum);
		
		JLabel lbl_id = new JLabel("ID");
		lbl_id.setBounds(25, 148, 57, 15);
		contentPane.add(lbl_id);
		
		JLabel lbl_paddwd = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lbl_paddwd.setBounds(25, 185, 57, 15);
		contentPane.add(lbl_paddwd);
		
		textField_ipadd = new JTextField();
		textField_ipadd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ip = textField_id.getText();
			}
		});
		textField_ipadd.setBounds(184, 28, 116, 21);
		contentPane.add(textField_ipadd);
		textField_ipadd.setColumns(10);
		
		textField_portnum = new JTextField();
		textField_portnum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String portnum = textField_portnum.getText();
			}
		});
		textField_portnum.setBounds(184, 59, 116, 21);
		contentPane.add(textField_portnum);
		textField_portnum.setColumns(10);
		
		textField_id = new JTextField();
		textField_id.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textField_id.getText();
			}
		});
		textField_id.setBounds(184, 145, 116, 21);
		contentPane.add(textField_id);
		textField_id.setColumns(10);
		
		textField_passwd = new JTextField();
		textField_passwd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// String ���� = textField_passwd.getText(); ���� �� ���� 
			}
		});
		textField_passwd.setBounds(184, 182, 116, 21);
		contentPane.add(textField_passwd);
		textField_passwd.setColumns(10);
		
		JButton btnExit = new JButton("\uC885\uB8CC");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);// ���� ��ư ����� â ���� 
			}
		});
		btnExit.setBounds(72, 228, 97, 23);
		contentPane.add(btnExit);
		
		JButton btnEnter = new JButton("\uC785\uC7A5");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 //new ChatFrame();
				setVisible(false);// ���� ��ư ����� ä��â���� �Ѿ. �켱�� ���Ƿ� .java ���� ���� �־����.
				// ���߿� ���̵� ��й�ȣ ��ġ ���� ���� �� ���̵� �Ǵ� ��й�ȣ�� ��ġ���� �ʽ��ϴ� â�� ������ �� .
				id = textField_id.getText();
				portnum = textField_portnum.getText();
				ip = textField_ipadd.getText();
				
				try {                       // ip�ּ�         //��Ʈ��ȣ
					Socket s1 = new Socket(ip, Integer.parseInt(portnum));
					System.out.println("������ ����.....");//connect 

					// i/o network stream :   readUTF() writeUTF() ����� ���� �غ�   
					DataOutputStream outputStream = new DataOutputStream(s1.getOutputStream());
					DataInputStream inputStream = new DataInputStream(s1.getInputStream());
					outputStream.writeUTF(id); 
					                            // �г��� ���� ������ ���� ���� 
					//�׷��� GUI�� ���� 
							 // KajaClientGUI.java�� GUI ����(��, main  x) 
							//==================================================
							//client console --> client GUI 
					new TcpMulClientGUI(outputStream, inputStream, id) {////////
			                   // io��Ʈ��    ��     �г����� ���ڷ� ����
						public void closeWork() throws IOException {
							outputStream.close();
						    inputStream.close();
						    System.exit(0);
					    }
			        }; //new KajaClientGUI -end
				} catch (Exception ee) {
							//e.printStackTrace();//�ּ��� �޾ƾ� ������ ȭ���� �ε巴�� ���� 
				}
			}
		});
		btnEnter.setBounds(203, 228, 97, 23);
		contentPane.add(btnEnter);
		
		setVisible(true); //�׻� ������ 
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
				System.exit(0); 
				setVisible(false);
			}
		});
		

	}

}
