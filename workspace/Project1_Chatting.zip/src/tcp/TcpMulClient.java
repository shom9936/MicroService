package tcp;

public class TcpMulClient {
	
	public static void main(String args[]) {

		new LoginGUI();

	}
}